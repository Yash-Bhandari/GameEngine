package levels;

import java.awt.Color;

import gameObjects.Bullet;
import gameObjects.Circle;
import gameObjects.Square;
import paint.Handler;
import paint.Input;

public class Level1 {
    public static void start(Handler handler, Input input) {
        Circle first = new Circle(20, 200, 300, true, Color.white, 3.5);
        handler.add(first);
        //handler.add(new Circle(40, 400, 400, false, Color.CYAN, 2));
        //handler.add(new Bullet(5, 200, 100, Color.black, 5, Math.PI));
    }
}
