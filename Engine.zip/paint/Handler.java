package paint;

import java.awt.Color;
import java.awt.Graphics;
import java.util.LinkedList;

import gameObjects.Bullet;
import gameObjects.GameObject;

public class Handler {

    public LinkedList<GameObject> objects;
    public GameObject controlled;
    private Input input;

    public Handler(Input input) {
        objects = new LinkedList<GameObject>();
        this.input = input;
    }

    public void add(GameObject go) {
        if (!go.inHandler) {
            objects.add(go);
            go.inHandler = true;
        }
        if (go.isControlled())
            controlled = go;
    }

    public void updateObjects() {
        if (input.shooting) {
            add(Bullet.createBullet(5, controlled.getX() + 5 / 2, controlled.getY() + 5 / 2, Color.black, 5, controlled.getAngle()));
            input.shooting = false;
        }

        for (GameObject go : objects) {
            if (go.inUse())
                go.update(input);
        }
    }

    public void renderObjects(Graphics g) {
        for (GameObject go : objects) {
            go.render(g);
        }
    }

    public void clear() {
        objects.clear();
    }

    public GameObject getControlled() {
        return controlled;
    }
}
