package gameObjects;

import java.awt.Color;
import java.awt.Graphics;

import paint.Game;

public class Bullet extends Circle {

    public static Bullet createBullet(int radius, int x, int y, Color color, double speed, double radians) {
        Bullet go;
        go = (Bullet)GameObject.repurpose(Bullet.class, x, y, false, color, speed);
        if (go != null) {
            go.setRadius(radius);
            go.xSpeed = Math.cos(radians) * go.speed;
            go.ySpeed = -Math.sin(radians) * go.speed;
            System.out.println("X speed : " + go.xSpeed + ", Y speed : " + go.ySpeed);
            return go;
        }
        else return new Bullet(radius, x, y, color, speed, radians);
    }
    
    protected void move() {
        x += xSpeed;
        y += ySpeed;
        //System.out.println("X speed : " + xSpeed + ", Y speed : " + ySpeed);
    }
    
    public Bullet(int radius, int x, int y, Color color, double speed, double radians) {
        super(radius, x, y, false, color, speed);
        this.xSpeed = Math.cos(radians) * speed;
        this.ySpeed = -Math.sin(radians) * speed;
    }
    
    @Override
    void checkBounds() {
        if (x < width / 2 && inUse)
            discard();
        if (x > Game.WIDTH - width / 2 - 1 && inUse)
            discard();
        if (y < height / 2 && inUse)
            discard();
        if (y > Game.HEIGHT - height / 2 - 1 && inUse)
            discard();
    }

}
